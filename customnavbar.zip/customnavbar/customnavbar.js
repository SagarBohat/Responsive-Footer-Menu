 const navSlider = ()=>{
    var burger=document.querySelector('.burgerLogo');
    var navcontainer=document.querySelector('.nav-container');
    var navItems=document.querySelectorAll('.nav-items');
  
  
    burger.addEventListener('click',function(){
           navcontainer.classList.toggle('nav-container-isopen');
           
           navItems.forEach((link,index)=>{
               if(link.style.animation)
               {link.style.animation='';}
               else{
               link.style.animation=`navContainerFade 500ms ease forwards ${index/4+0.5}s`;
            }
         
           });
           burger.classList.toggle('toggle');

    });
    

 
}
navSlider();

